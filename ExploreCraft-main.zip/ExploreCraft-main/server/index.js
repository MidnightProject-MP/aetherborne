const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000; // Use Render's port or 3000 for local dev

let playerDataPath;

if (process.env.RENDER === 'true') {
  playerDataPath = path.join('/mnt/data', 'playerData.json'); // Path on the Render persistent disk
  // Ensure the directory exists on Render disk (Render might not create it automatically for the file)
  // fs.mkdirSync(path.dirname(playerDataPath), { recursive: true }); // Consider if needed, usually Render handles mount point
} else {
  playerDataPath = path.join(__dirname, 'playerData.local.json'); // Local data file
}

app.use(express.static(path.join(__dirname, '../public')));
app.use(express.json()); // for parsing JSON body

app.post('/api/save-character', (req, res) => {
    const characterData = req.body;

    console.log('Received character data on server:', characterData);

    fs.writeFile(playerDataPath, JSON.stringify(characterData, null, 2), (err) => {
        if (err) {
            console.error('Error writing character data to file:', err);
            // Send an error response back to the client
            return res.status(500).json({ message: 'Failed to save character data on server.', error: err.message });
        }
        console.log('Character data saved successfully to', playerDataPath);
        // Send a success response back to the client
        res.status(200).json({ message: 'Character data saved successfully.' });
    });
});

app.get('/health', (req, res) => {
  res.status(200).send('OK');
});

// Endpoint to load character data
app.get('/api/load-character', async (req, res) => {
  try {
      const data = await fs.promises.readFile(playerDataPath, 'utf8');
      // It's good practice to also ensure the file isn't empty before parsing
      if (!data) {
        console.warn('playerData.json is empty, sending 404.');
        return res.status(404).json({ message: 'No character data found. File is empty.' });
      }
      res.status(200).json(JSON.parse(data)); // Can still throw if JSON is malformed
  } catch (error) {
      if (error.code === 'ENOENT') { // File not found
          console.warn(`File not found at ${playerDataPath}, sending 404.`);
          return res.status(404).json({ message: 'No character data found. File does not exist.' });
      }
      console.error('Error loading character data:', error); // Log the full error for server-side debugging
      res.status(500).json({ message: 'Failed to load character data.', error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
